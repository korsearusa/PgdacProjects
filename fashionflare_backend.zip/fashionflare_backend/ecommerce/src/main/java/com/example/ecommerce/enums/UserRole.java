package com.example.ecommerce.enums;

public enum UserRole {
	ADMIN, USER

}
