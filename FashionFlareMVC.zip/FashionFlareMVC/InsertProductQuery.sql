﻿insert into Products (Name,Brand,Category,Price,Description,ImageFileName,CreatedAt)
values
('Pratichi Dress','Pratichi','Cotton',5000,'Colors: Deep Purple, copper zari
Fabric: Mercerised Cotton
Technique: Handloom Jacquard 
Weaving Cluster: West Bengal
Measurements: 6.20 m x 1.14 m approx.
Blouse Piece : Yes','productPratichi1.webp',GETDATE()),
('Rumi Dress','Rumi','Silk',5000,'Colors: Deep Blue, copper zari
Fabric: Mercerised Silk
Technique: Handloom Jacquard 
Weaving Cluster: West Bengal
Measurements: 6.20 m x 1.14 m approx.
Blouse Piece : Yes','productPratichi1.webp',GETDATE());